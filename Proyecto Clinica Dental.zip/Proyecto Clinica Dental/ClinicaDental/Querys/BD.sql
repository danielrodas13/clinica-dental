create database clinica_bd;
go
use clinica_bd;
go
create table pacientes(
id int identity (1,1) PRIMARY KEY,
nombre varchar(50),
apellido varchar(50),
plan_tratamiento varchar(100),
fecha varchar(15)
);
