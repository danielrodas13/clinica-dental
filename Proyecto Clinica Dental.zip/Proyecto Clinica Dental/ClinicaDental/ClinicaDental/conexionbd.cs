﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlTypes;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using System.Windows.Forms;

namespace ClinicaDental
{
    internal class conexionbd
    {
        string cadena = "Data Source=JAASIEL_VASQUEZ\\SQLEXPRESS;Initial Catalog=pacientes; Integrated Security=True";
        public SqlConnection conect = new SqlConnection();

        public conexionbd()
        {
            conect.ConnectionString = cadena;
            MessageBox.Show("Conexion establecida con éxito");
        }
        public void abrir()
        {

            try { conect.Open(); }
            catch (Exception ex)
            {

                MessageBox.Show("Error al abrir la bd " + ex.Message);

            }

        }

        public void cerrar()
        {
            conect.Close();
        }

    }
}