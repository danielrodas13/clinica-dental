﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ClinicaDental
{
    public partial class Pacientes : Form
    {
        public Pacientes()
        {
            InitializeComponent();
        }
        string cadena = "Data Source=JAASIEL_VASQUEZ\\SQLEXPRESS;Initial Catalog=clinica_bd; Integrated Security=True";
        public SqlConnection conect = new SqlConnection("Data Source=JAASIEL_VASQUEZ\\SQLEXPRESS;Initial Catalog=clinica_bd; Integrated Security=True");
        private void pboxSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnRestaurar.Visible = false;
            btnMaximizar.Visible = true;
        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnMaximizar.Visible = false;
            btnRestaurar.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            txtFecha.Text = monthCalendar1.SelectionRange.Start.ToShortDateString();

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            var regresar = new Menu();
            regresar.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Pacientes_Load(object sender, EventArgs e)
        {

        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            if (textNombre.Text == "" || textApellido.Text=="" || texttratamiento.Text=="" || txtFecha.Text == "")
            {

                MessageBox.Show("Los campos no pueden estar vacío ");

            }else
            {

                conect.Open();
                string query = "Insert into dbo.pacientes (nombre, apellido, plan_tratamiento, fecha) values ('" + textNombre.Text + "' , '" + textApellido.Text + "' , '" + texttratamiento.Text + "' , '" + txtFecha.Text + "' ) ";
                SqlCommand commando = new SqlCommand(query, conect);
                commando.ExecuteNonQuery();
                MessageBox.Show("Paciente registrado correctamente");
                conect.Close();

                textNombre.Clear();
                textApellido.Clear();
                txtFecha.Clear();
                texttratamiento.Clear();

            }
            

        }

        private void texttratamiento_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            textNombre.Clear();
            textApellido.Clear();
            txtFecha.Clear();
            texttratamiento.Clear();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}
