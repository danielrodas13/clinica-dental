﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ClinicaDental
{
    public partial class Listado : Form
    {
        public Listado()
        {
            InitializeComponent();
        }
        string cadena = "Data Source=JAASIEL_VASQUEZ\\SQLEXPRESS;Initial Catalog=clinica_bd; Integrated Security=True";
        public SqlConnection conect = new SqlConnection("Data Source=JAASIEL_VASQUEZ\\SQLEXPRESS;Initial Catalog=clinica_bd; Integrated Security=True");
        private void pboxSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnRestaurar.Visible = false;
            btnMaximizar.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnMaximizar.Visible = false;
            btnRestaurar.Visible = true;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            var regresar = new Menu();
            regresar.Show();
        }

        private void Listado_Load(object sender, EventArgs e)
        {
            string consulta = "select id, nombre, apellido from pacientes";
            SqlDataAdapter adapter = new SqlDataAdapter(consulta, cadena);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            dtpacientes.DataSource = dt;
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);

        }
        



    }
}
